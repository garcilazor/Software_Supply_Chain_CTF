from setuptools import setup

setup(
    name="test_package",
    version="0.1.0",
    description="test package",
    author="Catriona McKay",
    author_email="catmckay@pdx.edu",
    license="MIT"
)
