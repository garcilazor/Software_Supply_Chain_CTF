from setuptools import setup
setup(name='record', 
    version='0.1',
    description='Record Creating Python Package', 
    author='@CyrusRice', 
    author_email='', 
    license='MIT', 
    packages=['record'],
    zip_safe=False)
