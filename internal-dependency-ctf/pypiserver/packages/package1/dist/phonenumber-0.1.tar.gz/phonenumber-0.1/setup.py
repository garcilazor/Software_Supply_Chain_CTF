from setuptools import setup
setup(name='phonenumber', 
    version='0.1',
    description='Phone Number Python Package', 
    author='@huy', 
    author_email='', 
    license='MIT', 
    packages=['phonenumber'],
    install_requires=
    [
        'PyMySQL'
    ],      
    zip_safe=False)