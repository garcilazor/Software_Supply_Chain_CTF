from setuptools import setup
setup(name='password', 
    version='0.1',
    description='Password Python Package', 
    author='@CyrusRice', 
    author_email='', 
    license='MIT', 
    packages=['password'],
    zip_safe=False)
